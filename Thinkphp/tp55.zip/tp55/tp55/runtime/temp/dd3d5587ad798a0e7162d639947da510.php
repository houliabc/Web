<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\phpStudy\PHPTutorial\WWW\tp55\public/../application/index\view\index\update.html";i:1732525668;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>修改密码</title>
    <style>
        body {
            font-family: "Microsoft YaHei", sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #2e8b57;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }
        .box {
            max-width: 400px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .row {
            margin-bottom: 15px;
        }
        .row label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .row input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btn {
            padding: 10px 15px;
            background-color: #2e8b57;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%; /* 使按钮宽度与输入框一致 */
        }
        .btn:hover {
            background-color: #246b45;
        }
        .menu a {
            display: inline-block;
            padding: 8px 15px;
            margin: 0 5px;
            color: #2e8b57;
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .menu a:hover {
            background-color: #2e8b57;
            color: white;
        }
    </style>
</head>
<body>
<h1>修改密码</h1>
<div class="box">
    <div class="menu">
        <div class="hello"><a href="<?php echo url('update'); ?>">欢迎您：<?php echo \think\Session::get('username'); ?></a></div>
        <a href="<?php echo url('index'); ?>">返回首页</a>
        <a href="<?php echo url('show'); ?>">我的留言</a>
        <a href="<?php echo url('User/logout'); ?>">退出登录</a>
        <p></p>
    </div>
    <form method="post" action="<?php echo url('do_update'); ?>">
        <div class="row">
            <label for="old_password">旧密码：</label>
            <input type="password" id="old_password" name="old_password" placeholder="请输入旧密码" required>
        </div>
        <div class="row">
            <label for="new_password">新密码：</label>
            <input type="password" id="new_password" name="new_password" placeholder="请输入新密码" required>
        </div>
        <div class="row">
            <label for="confirm_password">确认新密码：</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="请再次输入新密码" required>
        </div>
        <input type="submit" value="提交" class="btn">
    </form>
</div>
</body>
</html>