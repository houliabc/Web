<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\phpStudy\PHPTutorial\WWW\tp55\public/../application/index\view\index\post.html";i:1732524339;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>发布留言</title>
    <style>
        body {
            font-family: "Microsoft YaHei", sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #2e8b57;
            text-align: center;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .box {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .row {
            margin-bottom: 20px;
        }
        .row label {
            display: block;
            color: #333;
            margin-bottom: 8px;
            font-size: 16px;
        }
        .row input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .row input[type="text"]:focus {
            border-color: #2e8b57;
            outline: none;
            box-shadow: 0 0 5px rgba(46,139,87,0.2);
        }
        .btns {
            text-align: center;
            margin-top: 20px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        .btn-green {
            background-color: #2e8b57;
            color: white;
        }
        .btn-green:hover {
            background-color: #246b45;
        }
        .btn-gray {
            background-color: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }
        .btn-gray:hover {
            background-color: #e8e8e8;
        }
        .menu a {
            display: inline-block;
            padding: 8px 15px;
            margin: 0 5px;
            color: #2e8b57;
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .menu a:hover {
            background-color: #2e8b57;
            color: white;
        }
        .hello {
            color: #2e8b57;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <h1>发布留言</h1>
    <div class="box">
        <div class="menu">
            <div class="hello"><a href="<?php echo url('update'); ?>">欢迎您：<?php echo \think\Session::get('username'); ?></a></div>
            <a href="<?php echo url('index'); ?>">返回首页</a>
            <a href="<?php echo url('show'); ?>">我的留言</a>
            <a href="<?php echo url('User/logout'); ?>">退出登录</a>
            <p></p>
        </div>
        <form action="<?php echo url('do_post'); ?>" method="post">
            <div class="row">
                <label for="content">留言内容：</label>
                <input type="text" id="content" name="content" placeholder="请输入您的留言内容">
            </div>
            <div class="btns">
                <input type="submit" value="提交" class="btn btn-green">
                <input type="reset" value="重置" class="btn btn-gray">
            </div>
        </form>
    </div>
</body>
</html>