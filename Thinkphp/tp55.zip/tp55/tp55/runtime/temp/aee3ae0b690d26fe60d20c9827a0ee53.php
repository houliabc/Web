<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\phpstudy_pro\WWW\tp55\public/../application/index\view\index\show.html";i:1732519109;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>我的留言</title>
    <style>
        body {
            font-family: "Microsoft YaHei", sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #2e8b57;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .box {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .menu a {
            display: inline-block;
            padding: 8px 15px;
            margin: 0 5px;
            color: #2e8b57;
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .menu a:hover {
            background-color: #2e8b57;
            color: white;
        }
        .list {
            margin-top: 20px;
        }
        .item {
            border-bottom: 1px solid #eee;
            padding: 15px 0;
            text-align: left;
        }
        .text {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .info {
            color: #666;
            font-size: 14px;
        }
        .del {
            color: #ff4444;
        }
        .hello {
            color: #2e8b57;
            margin-bottom: 15px;
        }
        .page {
            margin-top: 20px;
        }
        .page {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 5px;
        }
        .page li {
            display: inline-block;
        }
        .page a, .page span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            color: #666;
            text-decoration: none;
            border-radius: 3px;
            transition: all 0.3s;
        }
        .page a:hover {
            background-color: #f5f5f5;
            border-color: #999;
        }
        .page .active span {
            background-color: #2e8b57;
            color: white;
            border-color: #2e8b57;
        }
        .page .disabled span {
            color: #ccc;
            cursor: not-allowed;
        }
        .btns {
            float: right;
            margin-bottom: 15px;
        }
        .btns .btn {
            padding: 8px 20px;
            font-size: 14px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            margin-left: 10px;
            transition: all 0.3s ease;
        }
        .btns .btn-green {
            background-color: #2e8b57;
            color: white;
        }
        .btns .btn-gray {
            background-color: #f0f0f0;
            color: #666;
        }
        .btns .btn-green:hover {
            background-color: #246b45;
        }
        .btns .btn-gray:hover {
            background-color: #e0e0e0;
        }
        /* 清除浮动 */
        .list {
            clear: both;
        }
        .del {
            color: #ff4444;
            text-decoration: none;
            font-size: 14px;
            margin-left: 10px;
        }
        .del:hover {
            color: #cc0000;
        }
    </style>
</head>
<body>
<h1 align="center">我的留言</h1>
<div class="box">
    <div class="hello">欢迎您：<?php echo \think\Session::get('username'); ?></div>
    <div class="menu">
        <a href="<?php echo url('index'); ?>">返回首页</a>
        <a href="<?php echo url('post'); ?>">发表留言</a>
        <a href="<?php echo url('User/logout'); ?>">退出登录</a>
    </div>
    
    <div class="mb-3">
        <div class="btns">
            <a href="<?php echo url('show', ['order'=>'desc']); ?>" 
               class="btn <?php echo \think\Request::instance()->param('order')=='asc'?'btn-gray':'btn-green'; ?>">
                最新发布
            </a>
            <a href="<?php echo url('show', ['order'=>'asc']); ?>" 
               class="btn <?php echo \think\Request::instance()->param('order')=='asc'?'btn-green':'btn-gray'; ?>">
                最早发布
            </a>
        </div>
    </div>
    
    <div class="list">
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <div class="item">
            <div class="text"><?php echo $item['content']; ?></div>
            <div class="info">
                留言人：<?php echo $item['username']; ?>&nbsp;&nbsp;
                留言时间：<?php echo date('Y年m月d日',$item['create_time']); ?>
                <a href="<?php echo url('delete?id='.$item['message_id']); ?>" onclick="return confirm('确定删除？')" class="del">删除</a>
            </div>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    
    <div class="page">
        <?php echo $list->render(); ?>
    </div>
</div>
</body>
</html>